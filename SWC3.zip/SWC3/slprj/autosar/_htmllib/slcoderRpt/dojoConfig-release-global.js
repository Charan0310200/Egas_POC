var dojoConfig = {
    tlmSiblingOfDojo: false,
    isDebug: false,
    async: true,
    has: {
        production: 1
    }
};
